# 🐾 PawTrust — Frontend Registration Page

**PawTrust** is a community pet care platform connecting loving pet parents with vetted, trusted neighborhood caregivers (dog walkers, pet sitters, overnight boarders, and drop-in visitors).

This project implements a complete, self-contained **Frontend Registration Experience** for new users with rich role adaptivity, real-time client-side validation, pet management, service rate configuration, and simulated backend responses.

---

## 🌟 Key Features

### 1. Dynamic Role-Adaptive Registration
- **Pet Owner**: Tailored flow to register pets, specify pet temperaments, veterinary contacts, and needed services (walking, sitting, boarding, daycare).
- **Pet Caregiver**: Tailored flow to configure offered services, custom hourly/overnight rates, years of experience, specialized care skills (oral meds, senior care, CPR/first aid), and home environment (fenced yard, house type).
- **Both (Owner & Caregiver)**: Seamless unified onboarding capturing both household pets and caregiving capabilities.

### 2. Multi-Step Onboarding Flow
1. **Account & Credentials**:
   - Role selector with visual cards and badges.
   - First & Last Name, Email, and auto-formatted Phone Number.
   - Interactive Password Strength Meter (Weak / Fair / Good / Strong) with real-time criteria checklist (8+ chars, uppercase, lowercase, number, symbol) and visibility toggles.
2. **Profile & Location**:
   - Profile picture selector with preset illustrated avatars or custom image upload preview.
   - Address, City, State, ZIP code, and preferred neighborhood travel/service radius.
   - Bio / About Me with live minimum character counter (20+ chars).
   - Emergency contact information.
3. **Pets & Services**:
   - **For Owners**: Interactive Pet Manager to add, preview, edit, or remove pets (species, breed suggestions, age, weight category, spayed/neutered status, temperament chips, medical notes, vet details) + Quick sample pet generator.
   - **For Caregivers**: Service rate configuration table ($/walk, $/day, $/night), certification flags, skill chips, and housing/yard details.
4. **Safety, Trust & Review**:
   - ID verification mock upload dropzone with preview.
   - Animal Welfare Code of Conduct pledge & Terms of Service modals.
   - Background check consent for service providers.
   - Formatted Review Summary card with "✏️ Edit" shortcuts jumping directly back to any step.

### 3. User Experience & Evaluation Utilities
- **1-Click Quick Demo Fill**: Dropdown in the header allows testing complete flows in one click:
  - *Fill as Pet Owner* (Sarah Jenkins & pets Cooper & Luna)
  - *Fill as Caregiver* (Marcus Chen & CPR certifications)
  - *Fill as Both* (Elena Rostova & Australian Shepherd Milo)
  - *Reset / Clear All*
- **Mock Server Response Selector**:
  - `201 Success`: Generates a mock member ID (`PT-XXXXXX`), auth token, and triggers celebration view.
  - `409 Duplicate Email`: Simulates conflict error handling with inline alert banner.
  - `500 Server Error`: Simulates network failure with retry guidance.
- **Celebration & Payload Inspector**:
  - Native HTML5 Canvas confetti animation (zero external libraries).
  - Collapsible JSON inspector showing the exact registered payload returned by the mock API with a "Copy JSON" button.
- **Draft Auto-Save**:
  - Form state automatically syncs to `localStorage` so refreshing never loses user input.

---

## 🚀 How to Run

Zero external build tools or internet connections are required. All styling and scripts are completely self-contained.

### Option 1: Direct File Open
Simply double-click [`index.html`](index.html) or run in terminal:
```bash
open index.html
```

### Option 2: Using Built-in Node Server (Recommended)
```bash
npm start
```
Then visit **`http://localhost:3000`** in your browser.

### Option 3: Using Python Built-in Server
```bash
python3 -m http.server 3000
```
Then visit **`http://localhost:3000`** in your browser.

---

## 🧪 Running Automated Tests

Run the test suite:
```bash
npm test
```
This tests:
- Email syntax validation & boundary checks
- Phone number formatting (`(XXX) XXX-XXXX`)
- Password strength criteria scoring
- Complete profile validation for Owner, Caregiver, and Dual-role datasets

---

## 📁 Project Structure

```
HW3-no-rules/
├── index.html              # Semantic HTML5 registration layout, modals & templates
├── css/
│   └── styles.css          # Design system, responsive layout, animations, components
├── js/
│   ├── app.js              # Application controller, DOM sync, step navigation
│   ├── validation.js       # Client-side validation logic & password analyzer
│   ├── data.js             # Avatar presets, breed lists, sample test profiles
│   ├── mockApi.js          # Simulated backend API, localStorage draft persistence
│   └── confetti.js         # Lightweight native HTML5 Canvas celebration particles
├── test/
│   └── validation.test.js  # Node.js automated test runner
├── server.js               # Zero-dependency static & mock API Node.js server
├── package.json            # Scripts & project metadata
└── README.md               # Documentation & usage guide
```

