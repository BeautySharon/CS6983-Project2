// test/validation.test.js - Automated tests for validation & data logic

const assert = require('assert');

// Mock browser globals for Node test environment
global.window = {};
require('../js/data.js');
require('../js/validation.js');

const PawValidation = global.PawValidation || window.PawValidation;
const PAWTRUST_DATA = global.PAWTRUST_DATA || window.PAWTRUST_DATA;

console.log('🧪 Starting PawTrust Validation Tests...\n');

// Test 1: Email Validation
console.log('Test 1: Email validation tests');
assert.strictEqual(PawValidation.isValidEmail('valid.user@example.com'), true);
assert.strictEqual(PawValidation.isValidEmail('user@sub.domain.org'), true);
assert.strictEqual(PawValidation.isValidEmail('invalid-email'), false);
assert.strictEqual(PawValidation.isValidEmail('invalid@'), false);
assert.strictEqual(PawValidation.isValidEmail('@domain.com'), false);
console.log('✓ Email validation passed\n');

// Test 2: Phone Formatting & Validation
console.log('Test 2: Phone formatting & validation tests');
assert.strictEqual(PawValidation.formatPhoneNumber('5552345678'), '(555) 234-5678');
assert.strictEqual(PawValidation.isValidPhone('(555) 234-5678'), true);
assert.strictEqual(PawValidation.isValidPhone('555-234-5678'), true);
assert.strictEqual(PawValidation.isValidPhone('12345'), false);
console.log('✓ Phone validation passed\n');

// Test 3: Password Strength Evaluation
console.log('Test 3: Password strength evaluation');
const weakPass = PawValidation.evaluatePassword('abc');
assert.strictEqual(weakPass.score <= 1, true);
assert.strictEqual(weakPass.isValid, false);

const strongPass = PawValidation.evaluatePassword('PawPassword2026!');
assert.strictEqual(strongPass.criteria.length, true);
assert.strictEqual(strongPass.criteria.uppercase, true);
assert.strictEqual(strongPass.criteria.lowercase, true);
assert.strictEqual(strongPass.criteria.number, true);
assert.strictEqual(strongPass.criteria.symbol, true);
assert.strictEqual(strongPass.isValid, true);
console.log('✓ Password strength evaluation passed\n');

// Test 4: Sample Profiles Completeness & Validity
console.log('Test 4: Verifying sample profiles against all validation rules');
['owner', 'caregiver', 'both'].forEach(profileKey => {
  const sample = PAWTRUST_DATA.sampleProfiles[profileKey];
  assert.ok(sample, `Sample profile ${profileKey} must exist`);

  const s1 = PawValidation.validateStep1(sample);
  assert.strictEqual(s1.isValid, true, `Step 1 must be valid for ${profileKey}: ` + JSON.stringify(s1.errors));

  const s2 = PawValidation.validateStep2(sample);
  assert.strictEqual(s2.isValid, true, `Step 2 must be valid for ${profileKey}: ` + JSON.stringify(s2.errors));

  const s3 = PawValidation.validateStep3(sample);
  assert.strictEqual(s3.isValid, true, `Step 3 must be valid for ${profileKey}: ` + JSON.stringify(s3.errors));

  const s4 = PawValidation.validateStep4(sample);
  assert.strictEqual(s4.isValid, true, `Step 4 must be valid for ${profileKey}: ` + JSON.stringify(s4.errors));

  const all = PawValidation.validateAll(sample);
  assert.strictEqual(all.isValid, true, `validateAll must pass for ${profileKey}: ` + JSON.stringify(all.errors));

  console.log(`✓ Sample profile "${profileKey}" fully passed all validation criteria`);
});

console.log('\n🎉 All PawTrust validation tests passed successfully!');

