// js/data.js - PawTrust data models, breeds, avatar presets, and sample test profiles

const PAWTRUST_DATA = {
  // Preset Avatars for users who don't want to upload their own photo
  avatarPresets: [
    {
      id: 'avatar-dog-lover',
      label: 'Dog Lover',
      svg: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="32" fill="#E6FFFA"/>
        <circle cx="32" cy="27" r="14" fill="#0D9488"/>
        <path d="M16 54C16 45.1634 23.1634 38 32 38C40.8366 38 48 45.1634 48 54" fill="#14B8A6"/>
        <path d="M42 22C44.2 22 46 20.2 46 18C46 15.8 44.2 14 42 14C39.8 14 38 15.8 38 18C38 20.2 39.8 22 42 22Z" fill="#F59E0B"/>
        <path d="M47 28C48.7 28 50 26.7 50 25C50 23.3 48.7 22 47 22C45.3 22 44 23.3 44 25C44 26.7 45.3 28 47 28Z" fill="#F59E0B"/>
        <circle cx="48" cy="18" r="3" fill="#F59E0B"/>
      </svg>`
    },
    {
      id: 'avatar-cat-pal',
      label: 'Cat Pal',
      svg: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="32" fill="#FEF3C7"/>
        <circle cx="32" cy="28" r="13" fill="#D97706"/>
        <polygon points="23,17 26,24 20,24" fill="#D97706"/>
        <polygon points="41,17 44,24 38,24" fill="#D97706"/>
        <path d="M18 54C18 46.268 24.268 40 32 40C39.732 40 46 46.268 46 54" fill="#F59E0B"/>
      </svg>`
    },
    {
      id: 'avatar-trusted-sitter',
      label: 'Caregiver Pro',
      svg: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="32" fill="#EFF6FF"/>
        <circle cx="32" cy="26" r="13" fill="#2563EB"/>
        <path d="M17 54C17 45.7157 23.7157 39 32 39C40.2843 39 47 45.7157 47 54" fill="#3B82F6"/>
        <circle cx="46" cy="46" r="10" fill="#10B981"/>
        <path d="M42 46L45 49L50 43" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`
    },
    {
      id: 'avatar-nature-walker',
      label: 'Active Walker',
      svg: `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="32" r="32" fill="#F0FDF4"/>
        <circle cx="32" cy="27" r="13" fill="#15803D"/>
        <path d="M17 54C17 45.7 23.7 39 32 39C40.3 39 47 45.7 47 54" fill="#22C55E"/>
        <path d="M48 22L51 27H45L48 22Z" fill="#15803D"/>
      </svg>`
    }
  ],

  // Species options & suggestions
  speciesOptions: [
    { id: 'dog', name: 'Dog', icon: '🐕' },
    { id: 'cat', name: 'Cat', icon: '🐈' },
    { id: 'bird', name: 'Bird', icon: '🦜' },
    { id: 'small_mammal', name: 'Rabbit / Small Pet', icon: '🐇' },
    { id: 'reptile', name: 'Reptile / Fish', icon: '🐢' },
    { id: 'other', name: 'Other Pet', icon: '🐾' }
  ],

  // Popular Breeds for auto-suggest
  popularBreeds: {
    dog: [
      'Golden Retriever', 'Labrador Retriever', 'French Bulldog', 'German Shepherd',
      'Poodle / Doodle Mix', 'Beagle', 'Corgi', 'Yorkshire Terrier', 'Boxer', 'Mixed Breed / Rescue'
    ],
    cat: [
      'Domestic Shorthair', 'Domestic Longhair', 'Maine Coon', 'Siamese', 'Ragdoll',
      'Persian', 'Bengal', 'British Shorthair', 'Rescue Mix'
    ],
    bird: ['Parakeet / Budgie', 'Cockatiel', 'Parrot', 'Canary', 'Lovebird'],
    small_mammal: ['Holland Lop Rabbit', 'Guinea Pig', 'Hamster', 'Ferret', 'Chinchilla']
  },

  // Sample Pre-fill Data sets for 1-Click Testing / Grading
  sampleProfiles: {
    owner: {
      accountType: 'owner',
      firstName: 'Sarah',
      lastName: 'Jenkins',
      email: 'sarah.jenkins@example.com',
      phone: '(555) 234-5678',
      password: 'PawPassword2026!',
      confirmPassword: 'PawPassword2026!',
      selectedAvatar: 'avatar-dog-lover',
      streetAddress: '742 Evergreen Terrace',
      city: 'Portland',
      state: 'OR',
      zipCode: '97201',
      neighborhoodRadius: '10',
      bio: 'Loving pet parent working hybrid. Looking for reliable, kind neighbors who can walk Cooper during weekdays and take care of Luna when I travel for conferences.',
      emergencyContactName: 'David Jenkins (Brother)',
      emergencyContactPhone: '(555) 987-6543',
      pets: [
        {
          id: 'pet_1',
          name: 'Cooper',
          species: 'dog',
          breed: 'Golden Retriever',
          age: '3 years',
          size: 'large',
          spayedNeutered: true,
          temperament: ['Friendly with Dogs', 'Good with Kids', 'High Energy'],
          medicalNotes: 'Fully vaccinated. Takes flea/tick preventative monthly. Loves fetch and squeaky balls!',
          vetClinic: 'Rose City Animal Hospital',
          vetPhone: '(555) 321-7788'
        },
        {
          id: 'pet_2',
          name: 'Luna',
          species: 'cat',
          breed: 'Domestic Shorthair',
          age: '5 years',
          size: 'small',
          spayedNeutered: true,
          temperament: ['Shy with Strangers', 'Calm & Gentle'],
          medicalNotes: 'Indoor-only cat. Needs dry food in morning, wet food at 6 PM. Shy for the first 10 minutes.',
          vetClinic: 'Rose City Animal Hospital',
          vetPhone: '(555) 321-7788'
        }
      ],
      servicesNeeded: ['walking', 'sitting', 'drop_in'],
      servicesOffered: {},
      caregiverExperience: {},
      homeEnvironment: {},
      idUploaded: true,
      idFileName: 'sarah_id_verification_front.jpg',
      smsNotifications: true,
      emailNotifications: true,
      agreeTerms: true,
      agreeWelfare: true,
      agreeBackgroundCheck: true
    },

    caregiver: {
      accountType: 'caregiver',
      firstName: 'Marcus',
      lastName: 'Chen',
      email: 'marcus.chen@example.com',
      phone: '(555) 876-5432',
      password: 'SafePetCare2026#',
      confirmPassword: 'SafePetCare2026#',
      selectedAvatar: 'avatar-trusted-sitter',
      streetAddress: '1240 Pinecrest Way',
      city: 'Seattle',
      state: 'WA',
      zipCode: '98101',
      neighborhoodRadius: '15',
      bio: 'Lifelong pet enthusiast and certified Pet CPR & First Aid provider. I have 6+ years of experience caring for active dogs, senior cats, and administering medication. Your pets will be treated like family.',
      emergencyContactName: 'Emily Chen (Spouse)',
      emergencyContactPhone: '(555) 654-3210',
      pets: [],
      servicesNeeded: [],
      servicesOffered: {
        walking: { enabled: true, rate: '25' },
        sitting: { enabled: true, rate: '65' },
        boarding: { enabled: true, rate: '75' },
        drop_in: { enabled: true, rate: '22' }
      },
      caregiverExperience: {
        yearsExperience: '6',
        cprCertified: true,
        skills: ['Oral Medication', 'Senior Pet Care', 'Puppy Care', 'Leash Training', 'High Energy Dogs']
      },
      homeEnvironment: {
        housingType: 'Single Family Home',
        yardType: 'Fully Fenced Yard (6ft)',
        otherPets: 'None currently',
        childrenAtHome: 'No',
        smokeFree: true
      },
      idUploaded: true,
      idFileName: 'marcus_chen_license_scan.pdf',
      smsNotifications: true,
      emailNotifications: true,
      agreeTerms: true,
      agreeWelfare: true,
      agreeBackgroundCheck: true
    },

    both: {
      accountType: 'both',
      firstName: 'Elena',
      lastName: 'Rostova',
      email: 'elena.rostova@example.com',
      phone: '(555) 432-1098',
      password: 'ElenaPets2026$!',
      confirmPassword: 'ElenaPets2026$!',
      selectedAvatar: 'avatar-nature-walker',
      streetAddress: '315 Maple Avenue',
      city: 'Denver',
      state: 'CO',
      zipCode: '80203',
      neighborhoodRadius: '8',
      bio: 'Pet mom to an adventurous Australian Shepherd named Milo. I work remotely from home with a large fenced yard and love hosting dog playdates, walks in the park, and helping neighborhood pet parents.',
      emergencyContactName: 'Michael Rostov (Partner)',
      emergencyContactPhone: '(555) 789-0123',
      pets: [
        {
          id: 'pet_both_1',
          name: 'Milo',
          species: 'dog',
          breed: 'Australian Shepherd',
          age: '2 years',
          size: 'medium',
          spayedNeutered: true,
          temperament: ['Friendly with Dogs', 'Good with Kids', 'Very Active'],
          medicalNotes: 'Microchipped, up to date on all shots. Loves running and agility games.',
          vetClinic: 'Mile High Veterinary Care',
          vetPhone: '(555) 456-7890'
        }
      ],
      servicesNeeded: ['sitting', 'boarding'],
      servicesOffered: {
        walking: { enabled: true, rate: '28' },
        boarding: { enabled: true, rate: '70' },
        drop_in: { enabled: true, rate: '24' }
      },
      caregiverExperience: {
        yearsExperience: '4',
        cprCertified: true,
        skills: ['Puppy Care', 'High Energy Dogs', 'Oral Medication']
      },
      homeEnvironment: {
        housingType: 'Single Family Home',
        yardType: 'Fully Fenced Yard (6ft)',
        otherPets: '1 friendly dog (Milo)',
        childrenAtHome: 'No',
        smokeFree: true
      },
      idUploaded: true,
      idFileName: 'elena_state_id.jpg',
      smsNotifications: true,
      emailNotifications: true,
      agreeTerms: true,
      agreeWelfare: true,
      agreeBackgroundCheck: true
    }
  },

  // Modal Legal / Safety copy
  legalTexts: {
    termsOfService: `
      <h3>PawTrust Terms of Service</h3>
      <p><strong>Effective Date:</strong> January 1, 2026</p>
      <p>Welcome to PawTrust. By registering an account, you agree to become part of a safe, respectful community dedicated to the well-being of companion animals.</p>
      <h4>1. Eligibility & Accounts</h4>
      <p>You must be at least 18 years old to create an account. You agree to provide accurate, truthful, and updated information regarding yourself, your pets, and any caregiving services offered.</p>
      <h4>2. Safety & Caregiver Screening</h4>
      <p>Caregivers offering pet boarding, sitting, or dog walking agree to undergo identity verification and authorized background checks. PawTrust reserves the right to suspend or remove profiles that fail safety screening.</p>
      <h4>3. The PawTrust Guarantee</h4>
      <p>Every booking scheduled through PawTrust is backed by the PawTrust Care & Safety Guarantee, including veterinary reimbursement coverage for eligible accidents occurring during scheduled services.</p>
      <h4>4. Cancellations & Conduct</h4>
      <p>Users must communicate respectfully and follow reasonable cancellation notice periods to ensure animal care is never compromised.</p>
    `,
    codeOfConduct: `
      <h3>PawTrust Animal Welfare Code of Conduct</h3>
      <p>PawTrust was founded on the fundamental principle that every animal deserves gentle, humane, and loving care.</p>
      <h4>Our Core Commitments:</h4>
      <ul>
        <li><strong>Force-Free Handling:</strong> We strictly prohibit physical punishment, shock collars, choke chains, or abusive force in any pet care session.</li>
        <li><strong>Continuous Supervision:</strong> Pets must never be left in hazardous environments, extreme heat or cold, or unsupervised around unfamiliar animals.</li>
        <li><strong>Prompt Medical Attention:</strong> Caregivers must immediately notify the pet owner and contact an emergency veterinarian if a pet exhibits acute distress or injury.</li>
        <li><strong>Clear Communication:</strong> Daily photo and text updates are standard practice to keep pet parents informed and reassured.</li>
      </ul>
    `
  }
};

window.PAWTRUST_DATA = PAWTRUST_DATA;

