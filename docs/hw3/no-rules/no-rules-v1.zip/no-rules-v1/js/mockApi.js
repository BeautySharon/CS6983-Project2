// js/mockApi.js - Mock API layer for simulated backend registration requests

const PawMockApi = {
  STORAGE_KEY_USERS: 'pawtrust_registered_users',
  STORAGE_KEY_DRAFT: 'pawtrust_registration_draft',
  SIMULATION_MODE_KEY: 'pawtrust_simulation_mode',

  // Current simulation mode: 'success' | 'duplicate_email' | 'server_error'
  currentMode: 'success',

  init() {
    const savedMode = localStorage.getItem(this.SIMULATION_MODE_KEY);
    if (savedMode) {
      this.currentMode = savedMode;
    }
  },

  setSimulationMode(mode) {
    this.currentMode = mode;
    localStorage.setItem(this.SIMULATION_MODE_KEY, mode);
  },

  getRegisteredUsers() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY_USERS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.warn('Failed to parse registered users from localStorage', e);
      return [];
    }
  },

  saveUser(user) {
    const users = this.getRegisteredUsers();
    users.unshift(user);
    localStorage.setItem(this.STORAGE_KEY_USERS, JSON.stringify(users));
  },

  saveDraft(data) {
    try {
      localStorage.setItem(this.STORAGE_KEY_DRAFT, JSON.stringify({
        data,
        timestamp: new Date().toISOString()
      }));
    } catch (e) {
      console.warn('Draft save failed', e);
    }
  },

  getDraft() {
    try {
      const draft = localStorage.getItem(this.STORAGE_KEY_DRAFT);
      return draft ? JSON.parse(draft) : null;
    } catch (e) {
      return null;
    }
  },

  clearDraft() {
    localStorage.removeItem(this.STORAGE_KEY_DRAFT);
  },

  // Simulated registration endpoint with progress callbacks and mock delay
  async registerUser(userData, onProgress) {
    return new Promise((resolve, reject) => {
      const steps = [
        { message: 'Connecting to PawTrust secure service...', delay: 350 },
        { message: 'Validating account credentials & email format...', delay: 450 },
        { message: 'Indexing pet profiles and neighborhood preferences...', delay: 500 },
        { message: 'Finalizing PawTrust member registration...', delay: 400 }
      ];

      let currentStep = 0;

      const runStep = () => {
        if (currentStep < steps.length) {
          if (onProgress) {
            onProgress(steps[currentStep].message, Math.round(((currentStep + 1) / steps.length) * 100));
          }
          const waitTime = steps[currentStep].delay;
          currentStep++;
          setTimeout(runStep, waitTime);
        } else {
          // Finished steps, check simulation mode
          if (this.currentMode === 'duplicate_email') {
            reject({
              status: 409,
              code: 'EMAIL_ALREADY_EXISTS',
              message: `An account with email '${userData.email}' already exists. Please log in or use a different email.`
            });
            return;
          }

          if (this.currentMode === 'server_error') {
            reject({
              status: 500,
              code: 'INTERNAL_SERVER_ERROR',
              message: 'Simulated 500 error: PawTrust network service is momentarily unavailable. Please retry.'
            });
            return;
          }

          // Success Response
          const createdUser = {
            id: 'paw_' + Math.random().toString(36).substr(2, 9),
            memberNumber: 'PT-' + Math.floor(100000 + Math.random() * 900000),
            registeredAt: new Date().toISOString(),
            status: 'active',
            verificationStatus: userData.accountType === 'caregiver' ? 'pending_bg_check' : 'verified_basic',
            ...userData,
            // Do not store plain text password in public record for safety simulation
            password: '••••••••••••'
          };

          this.saveUser(createdUser);
          this.clearDraft();

          resolve({
            status: 201,
            success: true,
            user: createdUser,
            token: 'jwt_mock_token_' + Math.random().toString(36).substring(2),
            message: 'Welcome to PawTrust! Your registration was completed successfully.'
          });
        }
      };

      runStep();
    });
  }
};

window.PawMockApi = PawMockApi;

