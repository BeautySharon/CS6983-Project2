// js/validation.js - Client-side validation logic for PawTrust registration

const PawValidation = {
  // Email regex
  emailRegex: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+$/,

  // Format phone number as (XXX) XXX-XXXX
  formatPhoneNumber(value) {
    if (!value) return '';
    const digits = value.replace(/\D/g, '').substring(0, 10);
    const len = digits.length;

    if (len < 4) return digits;
    if (len < 7) return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
    return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6, 10)}`;
  },

  // Check phone validity (10 digits)
  isValidPhone(phone) {
    const digits = (phone || '').replace(/\D/g, '');
    return digits.length === 10;
  },

  // Check email validity
  isValidEmail(email) {
    return this.emailRegex.test((email || '').trim());
  },

  // Password criteria check
  evaluatePassword(password) {
    const pwd = password || '';
    const criteria = {
      length: pwd.length >= 8,
      lowercase: /[a-z]/.test(pwd),
      uppercase: /[A-Z]/.test(pwd),
      number: /[0-9]/.test(pwd),
      symbol: /[^a-zA-Z0-9]/.test(pwd)
    };

    let score = 0;
    if (criteria.length) score++;
    if (criteria.lowercase && criteria.uppercase) score++;
    if (criteria.number) score++;
    if (criteria.symbol) score++;

    let label = 'Weak';
    let colorClass = 'strength-weak';
    let percent = 25;

    if (score === 0) {
      label = '';
      percent = 0;
      colorClass = '';
    } else if (score === 1) {
      label = 'Weak';
      percent = 25;
      colorClass = 'strength-weak';
    } else if (score === 2) {
      label = 'Fair';
      percent = 50;
      colorClass = 'strength-fair';
    } else if (score === 3) {
      label = 'Good';
      percent = 75;
      colorClass = 'strength-good';
    } else if (score >= 4) {
      label = 'Strong';
      percent = 100;
      colorClass = 'strength-strong';
    }

    return {
      criteria,
      score,
      label,
      percent,
      colorClass,
      isValid: score >= 3 && criteria.length
    };
  },

  // Validate Step 1: Account & Credentials
  validateStep1(formData) {
    const errors = {};

    if (!formData.accountType) {
      errors.accountType = 'Please select how you plan to use PawTrust.';
    }

    if (!formData.firstName || formData.firstName.trim().length < 2) {
      errors.firstName = 'First name must be at least 2 characters.';
    }

    if (!formData.lastName || formData.lastName.trim().length < 2) {
      errors.lastName = 'Last name must be at least 2 characters.';
    }

    if (!formData.email || !this.isValidEmail(formData.email)) {
      errors.email = 'Please enter a valid email address (e.g. name@domain.com).';
    }

    if (!formData.phone || !this.isValidPhone(formData.phone)) {
      errors.phone = 'Please enter a valid 10-digit phone number.';
    }

    const pwdCheck = this.evaluatePassword(formData.password);
    if (!formData.password || !pwdCheck.isValid) {
      errors.password = 'Password must meet at least 3 strength criteria including 8+ characters.';
    }

    if (!formData.confirmPassword || formData.password !== formData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match.';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  },

  // Validate Step 2: Profile & Location
  validateStep2(formData) {
    const errors = {};

    if (!formData.city || formData.city.trim().length < 2) {
      errors.city = 'Please enter your city.';
    }

    if (!formData.state || formData.state.trim().length === 0) {
      errors.state = 'Please select or enter your state / province.';
    }

    const zipDigits = (formData.zipCode || '').replace(/\D/g, '');
    if (zipDigits.length !== 5) {
      errors.zipCode = 'Please enter a valid 5-digit ZIP code.';
    }

    if (!formData.bio || formData.bio.trim().length < 20) {
      errors.bio = 'Please write at least 20 characters introducing yourself to the community.';
    }

    if (!formData.emergencyContactName || formData.emergencyContactName.trim().length < 2) {
      errors.emergencyContactName = 'Emergency contact name is required for pet safety.';
    }

    if (!formData.emergencyContactPhone || !this.isValidPhone(formData.emergencyContactPhone)) {
      errors.emergencyContactPhone = 'Please provide a valid 10-digit phone number for emergency contact.';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  },

  // Validate Step 3: Role-specific details (Pets or Caregiver Services)
  validateStep3(formData) {
    const errors = {};
    const role = formData.accountType;

    // Pet Owner or Both checks
    if (role === 'owner' || role === 'both') {
      if (!formData.pets || formData.pets.length === 0) {
        errors.pets = 'Please add at least one pet to your family profile.';
      }
      if (!formData.servicesNeeded || formData.servicesNeeded.length === 0) {
        errors.servicesNeeded = 'Please select at least one pet care service you may need.';
      }
    }

    // Caregiver or Both checks
    if (role === 'caregiver' || role === 'both') {
      const offered = formData.servicesOffered || {};
      const activeServices = Object.keys(offered).filter(k => offered[k] && offered[k].enabled);

      if (activeServices.length === 0) {
        errors.servicesOffered = 'Please select at least one service you wish to offer.';
      } else {
        // Check that active services have valid numeric rates
        for (const s of activeServices) {
          const rateVal = parseFloat(offered[s].rate);
          if (isNaN(rateVal) || rateVal <= 0) {
            errors.servicesOffered = `Please set a valid dollar rate for ${s.replace('_', ' ')}.`;
            break;
          }
        }
      }

      if (!formData.caregiverExperience || !formData.caregiverExperience.yearsExperience) {
        errors.yearsExperience = 'Please indicate your years of pet care experience.';
      }
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  },

  // Validate Step 4: Trust, Safety & Agreements
  validateStep4(formData) {
    const errors = {};

    if (!formData.agreeTerms) {
      errors.agreeTerms = 'You must agree to the PawTrust Terms of Service and Privacy Policy.';
    }

    if (!formData.agreeWelfare) {
      errors.agreeWelfare = 'You must agree to the Animal Welfare Code of Conduct.';
    }

    if ((formData.accountType === 'caregiver' || formData.accountType === 'both') && !formData.agreeBackgroundCheck) {
      errors.agreeBackgroundCheck = 'Caregivers must consent to the standard identity and background verification.';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  },

  // Validate entire form
  validateAll(formData) {
    const s1 = this.validateStep1(formData);
    const s2 = this.validateStep2(formData);
    const s3 = this.validateStep3(formData);
    const s4 = this.validateStep4(formData);

    const allErrors = {
      ...s1.errors,
      ...s2.errors,
      ...s3.errors,
      ...s4.errors
    };

    return {
      isValid: Object.keys(allErrors).length === 0,
      errors: allErrors,
      stepValidity: {
        step1: s1.isValid,
        step2: s2.isValid,
        step3: s3.isValid,
        step4: s4.isValid
      }
    };
  }
};

window.PawValidation = PawValidation;

