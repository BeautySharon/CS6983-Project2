// js/app.js - PawTrust Registration Application Controller

document.addEventListener('DOMContentLoaded', () => {
  // Initialize state and sub-modules
  PawMockApi.init();
  PawConfetti.init();

  const App = {
    currentStep: 1,
    maxSteps: 4,
    formData: {
      accountType: 'owner',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: '',
      selectedAvatar: 'avatar-dog-lover',
      customAvatarDataUrl: null,
      streetAddress: '',
      city: '',
      state: '',
      zipCode: '',
      neighborhoodRadius: '10',
      bio: '',
      emergencyContactName: '',
      emergencyContactPhone: '',
      pets: [],
      servicesNeeded: ['walking', 'sitting'],
      servicesOffered: {
        walking: { enabled: true, rate: '25' },
        sitting: { enabled: true, rate: '65' },
        boarding: { enabled: true, rate: '70' },
        drop_in: { enabled: true, rate: '22' }
      },
      caregiverExperience: {
        yearsExperience: '3',
        cprCertified: true,
        skills: ['Oral Medication', 'Senior Pet Care', 'Puppy Care', 'High Energy Dogs']
      },
      homeEnvironment: {
        housingType: 'Single Family Home',
        yardType: 'Fully Fenced Yard (6ft)'
      },
      idUploaded: false,
      idFileName: '',
      smsNotifications: true,
      emailNotifications: true,
      agreeTerms: false,
      agreeWelfare: false,
      agreeBackgroundCheck: false
    },

    init() {
      this.cacheDom();
      this.bindEvents();
      this.initAvatarPresets();
      this.initLegalModals();
      this.initBreedSuggestions('dog');
      this.loadDraftOrDefaults();
      this.updateRoleView();
      this.renderPetsList();
      this.updateStepView();
    },

    cacheDom() {
      this.dom = {
        // Form & navigation
        form: document.getElementById('registrationForm'),
        stepContents: document.querySelectorAll('.step-content'),
        stepNodes: document.querySelectorAll('.step-node'),
        stepperProgressFill: document.getElementById('stepperProgressFill'),
        step3Label: document.getElementById('step3Label'),
        btnPrevStep: document.getElementById('btnPrevStep'),
        btnNextStep: document.getElementById('btnNextStep'),
        btnSubmitRegistration: document.getElementById('btnSubmitRegistration'),
        formAlertBanner: document.getElementById('formAlertBanner'),
        formAlertMessage: document.getElementById('formAlertMessage'),
        draftStatusText: document.getElementById('draftStatusText'),

        // Role selectors
        roleCards: {
          owner: document.getElementById('roleCardOwner'),
          caregiver: document.getElementById('roleCardCaregiver'),
          both: document.getElementById('roleCardBoth')
        },
        sectionOwnerDetails: document.getElementById('sectionOwnerDetails'),
        sectionCaregiverDetails: document.getElementById('sectionCaregiverDetails'),
        bgCheckAgreementRow: document.getElementById('bgCheckAgreementRow'),

        // Step 1 controls
        firstNameInput: document.getElementById('firstName'),
        lastNameInput: document.getElementById('lastName'),
        emailInput: document.getElementById('email'),
        phoneInput: document.getElementById('phone'),
        passwordInput: document.getElementById('password'),
        confirmPasswordInput: document.getElementById('confirmPassword'),
        passwordMeterFill: document.getElementById('passwordMeterFill'),
        ruleLength: document.getElementById('ruleLength'),
        ruleUpper: document.getElementById('ruleUpper'),
        ruleLower: document.getElementById('ruleLower'),
        ruleNumberOrSymbol: document.getElementById('ruleNumberOrSymbol'),

        // Step 2 controls
        avatarPreviewContainer: document.getElementById('avatarPreviewContainer'),
        avatarPresetsContainer: document.getElementById('avatarPresetsContainer'),
        avatarFileInput: document.getElementById('avatarFileInput'),
        streetAddressInput: document.getElementById('streetAddress'),
        cityInput: document.getElementById('city'),
        stateSelect: document.getElementById('state'),
        zipCodeInput: document.getElementById('zipCode'),
        neighborhoodRadiusSelect: document.getElementById('neighborhoodRadius'),
        bioTextarea: document.getElementById('bio'),
        bioCounter: document.getElementById('bioCounter'),
        emergencyContactNameInput: document.getElementById('emergencyContactName'),
        emergencyContactPhoneInput: document.getElementById('emergencyContactPhone'),

        // Step 3 controls
        petsListContainer: document.getElementById('petsListContainer'),
        btnOpenAddPetModal: document.getElementById('btnOpenAddPetModal'),
        btnQuickAddSamplePet: document.getElementById('btnQuickAddSamplePet'),
        caregiverSkillsChips: document.getElementById('caregiverSkillsChips'),
        yearsExperienceSelect: document.getElementById('yearsExperience'),
        housingTypeSelect: document.getElementById('housingType'),
        yardTypeSelect: document.getElementById('yardType'),

        // Step 4 controls
        idDropZone: document.getElementById('idDropZone'),
        idUploadStatus: document.getElementById('idUploadStatus'),
        idFileInput: document.getElementById('idFileInput'),
        agreeTermsCheckbox: document.getElementById('agreeTerms'),
        agreeWelfareCheckbox: document.getElementById('agreeWelfare'),
        agreeBackgroundCheckCheckbox: document.getElementById('agreeBackgroundCheck'),
        agreeNotificationsCheckbox: document.getElementById('agreeNotifications'),

        // Review summary
        revName: document.getElementById('rev_name'),
        revRole: document.getElementById('rev_role'),
        revEmail: document.getElementById('rev_email'),
        revPhone: document.getElementById('rev_phone'),
        revLocation: document.getElementById('rev_location'),
        revEmergency: document.getElementById('rev_emergency'),
        revPetsSummary: document.getElementById('rev_pets_summary'),

        // Modals & Overlay
        submitOverlay: document.getElementById('submitOverlay'),
        submitStatusTitle: document.getElementById('submitStatusTitle'),
        submitStatusDesc: document.getElementById('submitStatusDesc'),
        submitProgressBar: document.getElementById('submitProgressBar'),
        petModal: document.getElementById('petModal'),
        petForm: document.getElementById('petForm'),
        btnSavePet: document.getElementById('btnSavePet'),
        petModalHeading: document.getElementById('petModalHeading'),
        petEditId: document.getElementById('petEditId'),
        petModalName: document.getElementById('petModalName'),
        petModalSpecies: document.getElementById('petModalSpecies'),
        petModalBreed: document.getElementById('petModalBreed'),
        petModalAge: document.getElementById('petModalAge'),
        petModalSize: document.getElementById('petModalSize'),
        petModalSpayed: document.getElementById('petModalSpayed'),
        petModalMedical: document.getElementById('petModalMedical'),
        petModalVetClinic: document.getElementById('petModalVetClinic'),
        petModalVetPhone: document.getElementById('petModalVetPhone'),
        petTemperamentChips: document.getElementById('petTemperamentChips'),
        breedDatalist: document.getElementById('breedDatalist'),

        // Success View
        successView: document.getElementById('successView'),
        successWelcomeMsg: document.getElementById('successWelcomeMsg'),
        successMemberId: document.getElementById('successMemberId'),
        successAccountTypeBadge: document.getElementById('successAccountTypeBadge'),
        payloadJsonPre: document.getElementById('payloadJsonPre'),
        btnTogglePayloadDrawer: document.getElementById('btnTogglePayloadDrawer'),
        btnCopyPayload: document.getElementById('btnCopyPayload'),
        btnResetAndRegisterAnother: document.getElementById('btnResetAndRegisterAnother'),

        // Top tools
        btnDemoDropdown: document.getElementById('btnDemoDropdown'),
        demoMenu: document.getElementById('demoMenu'),
        btnClearForm: document.getElementById('btnClearForm'),
        simulationModeSelect: document.getElementById('simulationModeSelect')
      };
    },

    bindEvents() {
      // Step navigation
      this.dom.btnNextStep.addEventListener('click', () => this.handleNextStep());
      this.dom.btnPrevStep.addEventListener('click', () => this.handlePrevStep());
      this.dom.form.addEventListener('submit', (e) => this.handleFormSubmit(e));

      // Click on stepper nodes directly if already reached
      this.dom.stepNodes.forEach(node => {
        node.addEventListener('click', () => {
          const targetStep = parseInt(node.getAttribute('data-step'), 10);
          if (targetStep < this.currentStep) {
            this.goToStep(targetStep);
          } else if (targetStep > this.currentStep) {
            // validate up to target step
            if (this.validateCurrentStep()) {
              this.goToStep(targetStep);
            }
          }
        });
      });

      // Role selection change
      document.querySelectorAll('input[name="accountType"]').forEach(radio => {
        radio.addEventListener('change', (e) => {
          this.formData.accountType = e.target.value;
          this.updateRoleView();
          this.saveDraftDebounced();
        });
      });

      // Password strength & visibility toggles
      this.dom.passwordInput.addEventListener('input', () => this.handlePasswordInput());
      this.dom.confirmPasswordInput.addEventListener('input', () => this.handleConfirmPasswordInput());

      document.querySelectorAll('.toggle-password-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const targetId = btn.getAttribute('data-target');
          const input = document.getElementById(targetId);
          if (!input) return;
          const isPass = input.type === 'password';
          input.type = isPass ? 'text' : 'password';
          btn.querySelector('.eye-open').style.display = isPass ? 'none' : 'block';
          btn.querySelector('.eye-closed').style.display = isPass ? 'block' : 'none';
        });
      });

      // Phone formatting
      this.dom.phoneInput.addEventListener('input', (e) => {
        e.target.value = PawValidation.formatPhoneNumber(e.target.value);
        this.saveDraftDebounced();
      });

      this.dom.emergencyContactPhoneInput.addEventListener('input', (e) => {
        e.target.value = PawValidation.formatPhoneNumber(e.target.value);
        this.saveDraftDebounced();
      });

      // Bio character counter
      this.dom.bioTextarea.addEventListener('input', () => {
        const len = this.dom.bioTextarea.value.trim().length;
        this.dom.bioCounter.textContent = `${len} / 20 min characters`;
        if (len >= 20) {
          this.dom.bioCounter.style.color = 'var(--emerald-600)';
        } else {
          this.dom.bioCounter.style.color = 'var(--slate-500)';
        }
        this.saveDraftDebounced();
      });

      // Avatar custom file upload
      this.dom.avatarFileInput.addEventListener('change', (e) => this.handleCustomAvatarUpload(e));

      // ID document upload
      this.dom.idFileInput.addEventListener('change', (e) => this.handleIdDocumentUpload(e));

      // Caregiver rates inputs & toggles
      ['walking', 'sitting', 'boarding', 'dropin'].forEach(service => {
        const chk = document.getElementById(`offer_${service}`);
        const rateInput = document.getElementById(`rate_${service}`);
        const row = document.getElementById(`rateRow_${service}`);

        if (chk && rateInput && row) {
          chk.addEventListener('change', () => {
            row.classList.toggle('active', chk.checked);
            rateInput.disabled = !chk.checked;
            this.syncCaregiverRatesFromDom();
            this.saveDraftDebounced();
          });
          rateInput.addEventListener('input', () => {
            this.syncCaregiverRatesFromDom();
            this.saveDraftDebounced();
          });
        }
      });

      // Caregiver skills chip toggles
      this.dom.caregiverSkillsChips.querySelectorAll('.choice-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          chip.classList.toggle('active');
          this.syncCaregiverSkillsFromDom();
          this.saveDraftDebounced();
        });
      });

      // Services Needed checkboxes (for owners)
      document.querySelectorAll('input[name="servicesNeeded"]').forEach(chk => {
        chk.addEventListener('change', () => {
          const parentCard = chk.closest('.service-check-card');
          if (parentCard) parentCard.classList.toggle('checked', chk.checked);
          this.syncServicesNeededFromDom();
          this.saveDraftDebounced();
        });
      });

      // Pet Modal openers
      this.dom.btnOpenAddPetModal.addEventListener('click', () => this.openPetModal());
      this.dom.btnQuickAddSamplePet.addEventListener('click', () => this.quickAddSamplePet());
      this.dom.btnSavePet.addEventListener('click', () => this.handleSavePet());

      // Pet species change -> updates breed datalist
      this.dom.petModalSpecies.addEventListener('change', (e) => {
        this.initBreedSuggestions(e.target.value);
      });

      // Pet temperament chip toggles in modal
      this.dom.petTemperamentChips.querySelectorAll('.choice-chip').forEach(chip => {
        chip.addEventListener('click', () => chip.classList.toggle('active'));
      });

      // Close modal triggers
      document.querySelectorAll('[data-close-modal]').forEach(btn => {
        btn.addEventListener('click', () => {
          const targetModalId = btn.getAttribute('data-close-modal');
          this.closeModal(targetModalId);
        });
      });

      // Open read modals (terms & welfare)
      document.querySelectorAll('.link-read-modal').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          const targetModalId = btn.getAttribute('data-modal');
          this.openModal(targetModalId);
        });
      });

      // Review Edit links (jump directly to step)
      document.querySelectorAll('.btn-review-edit').forEach(btn => {
        btn.addEventListener('click', () => {
          const step = parseInt(btn.getAttribute('data-goto-step'), 10);
          this.goToStep(step);
        });
      });

      // Quick Demo Fill Menu
      this.dom.btnDemoDropdown.addEventListener('click', (e) => {
        e.stopPropagation();
        this.dom.demoMenu.classList.toggle('show');
      });

      document.addEventListener('click', () => {
        this.dom.demoMenu.classList.remove('show');
      });

      document.querySelectorAll('.demo-menu-item[data-fill]').forEach(item => {
        item.addEventListener('click', () => {
          const profileType = item.getAttribute('data-fill');
          this.applySampleProfile(profileType);
          this.dom.demoMenu.classList.remove('show');
        });
      });

      this.dom.btnClearForm.addEventListener('click', () => {
        if (confirm('Are you sure you want to clear this registration form?')) {
          PawMockApi.clearDraft();
          window.location.reload();
        }
      });

      // Simulation mode selector
      this.dom.simulationModeSelect.value = PawMockApi.currentMode;
      this.dom.simulationModeSelect.addEventListener('change', (e) => {
        PawMockApi.setSimulationMode(e.target.value);
      });

      // Payload copy button
      this.dom.btnCopyPayload.addEventListener('click', () => {
        const text = this.dom.payloadJsonPre.textContent;
        navigator.clipboard.writeText(text).then(() => {
          this.dom.btnCopyPayload.textContent = '✓ Copied!';
          setTimeout(() => { this.dom.btnCopyPayload.textContent = 'Copy JSON'; }, 2000);
        });
      });

      // Register another new user
      this.dom.btnResetAndRegisterAnother.addEventListener('click', () => {
        PawMockApi.clearDraft();
        window.location.reload();
      });

      // Auto save on any input change inside form
      this.dom.form.addEventListener('input', () => this.saveDraftDebounced());
      this.dom.form.addEventListener('change', () => this.saveDraftDebounced());
    },

    // ------------------------------------------------------------------------
    // Step & Navigation Controller
    // ------------------------------------------------------------------------
    handleNextStep() {
      if (!this.validateCurrentStep()) {
        return;
      }
      if (this.currentStep < this.maxSteps) {
        this.goToStep(this.currentStep + 1);
      }
    },

    handlePrevStep() {
      if (this.currentStep > 1) {
        this.goToStep(this.currentStep - 1);
      }
    },

    goToStep(stepNumber) {
      this.clearAlertBanner();
      this.currentStep = stepNumber;
      this.updateStepView();

      // Scroll smoothly to card top for comfortable view
      this.dom.form.closest('.registration-card').scrollIntoView({ behavior: 'smooth', block: 'start' });

      if (this.currentStep === 4) {
        this.renderReviewSummary();
      }
    },

    updateStepView() {
      // Toggle step contents
      this.dom.stepContents.forEach(content => {
        const step = parseInt(content.getAttribute('data-step'), 10);
        content.classList.toggle('active', step === this.currentStep);
      });

      // Update stepper nodes & line
      this.dom.stepNodes.forEach(node => {
        const step = parseInt(node.getAttribute('data-step'), 10);
        node.classList.remove('active', 'completed');

        if (step === this.currentStep) {
          node.classList.add('active');
          node.querySelector('.step-circle').textContent = step;
        } else if (step < this.currentStep) {
          node.classList.add('completed');
          node.querySelector('.step-circle').innerHTML = '✓';
        } else {
          node.querySelector('.step-circle').textContent = step;
        }
      });

      const fillPercentage = ((this.currentStep - 1) / (this.maxSteps - 1)) * 100;
      this.dom.stepperProgressFill.style.width = `${fillPercentage}%`;

      // Update navigation buttons
      this.dom.btnPrevStep.disabled = this.currentStep === 1;

      if (this.currentStep === this.maxSteps) {
        this.dom.btnNextStep.style.display = 'none';
        this.dom.btnSubmitRegistration.style.display = 'inline-flex';
      } else {
        this.dom.btnNextStep.style.display = 'inline-flex';
        this.dom.btnSubmitRegistration.style.display = 'none';

        // Contextual next button text
        const nextLabels = {
          1: 'Continue to Profile & Location',
          2: this.formData.accountType === 'caregiver' ? 'Continue to Caregiver Services' : 'Continue to Pets & Services',
          3: 'Continue to Safety & Review'
        };
        this.dom.btnNextStep.querySelector('span').textContent = nextLabels[this.currentStep] || 'Next Step';
      }

      // Update step 3 label in stepper header
      if (this.formData.accountType === 'caregiver') {
        this.dom.step3Label.textContent = 'Caregiver Services';
      } else if (this.formData.accountType === 'both') {
        this.dom.step3Label.textContent = 'Pets & Services';
      } else {
        this.dom.step3Label.textContent = 'Pet Family';
      }
    },

    updateRoleView() {
      const role = this.formData.accountType;

      // Update radio card active states
      Object.keys(this.dom.roleCards).forEach(key => {
        const card = this.dom.roleCards[key];
        const isMatch = key === role;
        card.classList.toggle('selected', isMatch);
        const radio = card.querySelector('input[type="radio"]');
        if (radio) radio.checked = isMatch;
      });

      // Show/hide sections in Step 3
      if (role === 'owner') {
        this.dom.sectionOwnerDetails.style.display = 'block';
        this.dom.sectionCaregiverDetails.style.display = 'none';
        this.dom.bgCheckAgreementRow.style.display = 'none';
      } else if (role === 'caregiver') {
        this.dom.sectionOwnerDetails.style.display = 'none';
        this.dom.sectionCaregiverDetails.style.display = 'block';
        this.dom.bgCheckAgreementRow.style.display = 'flex';
      } else { // 'both'
        this.dom.sectionOwnerDetails.style.display = 'block';
        this.dom.sectionCaregiverDetails.style.display = 'block';
        this.dom.bgCheckAgreementRow.style.display = 'flex';
      }

      this.updateStepView();
    },

    // ------------------------------------------------------------------------
    // Validation Handlers
    // ------------------------------------------------------------------------
    syncFormDataFromDom() {
      this.formData.firstName = this.dom.firstNameInput.value.trim();
      this.formData.lastName = this.dom.lastNameInput.value.trim();
      this.formData.email = this.dom.emailInput.value.trim();
      this.formData.phone = this.dom.phoneInput.value.trim();
      this.formData.password = this.dom.passwordInput.value;
      this.formData.confirmPassword = this.dom.confirmPasswordInput.value;

      this.formData.streetAddress = this.dom.streetAddressInput.value.trim();
      this.formData.city = this.dom.cityInput.value.trim();
      this.formData.state = this.dom.stateSelect.value;
      this.formData.zipCode = this.dom.zipCodeInput.value.trim();
      this.formData.neighborhoodRadius = this.dom.neighborhoodRadiusSelect.value;
      this.formData.bio = this.dom.bioTextarea.value.trim();
      this.formData.emergencyContactName = this.dom.emergencyContactNameInput.value.trim();
      this.formData.emergencyContactPhone = this.dom.emergencyContactPhoneInput.value.trim();

      this.formData.caregiverExperience.yearsExperience = this.dom.yearsExperienceSelect.value;
      this.formData.homeEnvironment.housingType = this.dom.housingTypeSelect.value;
      this.formData.homeEnvironment.yardType = this.dom.yardTypeSelect.value;

      this.formData.agreeTerms = this.dom.agreeTermsCheckbox.checked;
      this.formData.agreeWelfare = this.dom.agreeWelfareCheckbox.checked;
      this.formData.agreeBackgroundCheck = this.dom.agreeBackgroundCheckCheckbox.checked;
      this.formData.smsNotifications = this.dom.agreeNotificationsCheckbox.checked;
    },

    validateCurrentStep() {
      this.syncFormDataFromDom();
      this.clearAllFieldErrors();

      let validationResult;
      if (this.currentStep === 1) {
        validationResult = PawValidation.validateStep1(this.formData);
      } else if (this.currentStep === 2) {
        validationResult = PawValidation.validateStep2(this.formData);
      } else if (this.currentStep === 3) {
        validationResult = PawValidation.validateStep3(this.formData);
      } else if (this.currentStep === 4) {
        validationResult = PawValidation.validateStep4(this.formData);
      }

      if (!validationResult.isValid) {
        this.displayFieldErrors(validationResult.errors);
        this.showAlertBanner('Please resolve the highlighted fields before proceeding.');
        return false;
      }

      this.clearAlertBanner();
      return true;
    },

    displayFieldErrors(errors) {
      let firstErrorElement = null;

      Object.keys(errors).forEach(fieldId => {
        const errorSpan = document.getElementById(`error_${fieldId}`);
        const inputElem = document.getElementById(fieldId);

        if (errorSpan) {
          errorSpan.textContent = errors[fieldId];
          errorSpan.classList.add('show');
        }

        if (inputElem) {
          inputElem.classList.add('is-invalid');
          if (!firstErrorElement) firstErrorElement = inputElem;
        }
      });

      if (firstErrorElement) {
        firstErrorElement.focus();
      }
    },

    clearAllFieldErrors() {
      document.querySelectorAll('.field-error').forEach(el => {
        el.textContent = '';
        el.classList.remove('show');
      });
      document.querySelectorAll('.form-input, .form-select, .form-textarea').forEach(el => {
        el.classList.remove('is-invalid');
      });
    },

    showAlertBanner(message) {
      this.dom.formAlertMessage.textContent = message;
      this.dom.formAlertBanner.classList.add('show');
    },

    clearAlertBanner() {
      this.dom.formAlertBanner.classList.remove('show');
    },

    // ------------------------------------------------------------------------
    // Password Strength Evaluator
    // ------------------------------------------------------------------------
    handlePasswordInput() {
      const pwd = this.dom.passwordInput.value;
      const evalResult = PawValidation.evaluatePassword(pwd);

      // Update fill bar
      this.dom.passwordMeterFill.className = 'password-meter-fill ' + evalResult.colorClass;

      // Update criteria items
      const crit = evalResult.criteria;
      this.dom.ruleLength.classList.toggle('valid', crit.length);
      this.dom.ruleUpper.classList.toggle('valid', crit.uppercase);
      this.dom.ruleLower.classList.toggle('valid', crit.lowercase);
      this.dom.ruleNumberOrSymbol.classList.toggle('valid', crit.number || crit.symbol);

      this.handleConfirmPasswordInput();
    },

    handleConfirmPasswordInput() {
      const pwd = this.dom.passwordInput.value;
      const confirmPwd = this.dom.confirmPasswordInput.value;
      const errorConfirm = document.getElementById('error_confirmPassword');

      if (confirmPwd.length > 0 && pwd !== confirmPwd) {
        errorConfirm.textContent = 'Passwords do not match.';
        errorConfirm.classList.add('show');
        this.dom.confirmPasswordInput.classList.add('is-invalid');
      } else {
        errorConfirm.textContent = '';
        errorConfirm.classList.remove('show');
        this.dom.confirmPasswordInput.classList.remove('is-invalid');
      }
    },

    // ------------------------------------------------------------------------
    // Avatar Preset & Custom Upload
    // ------------------------------------------------------------------------
    initAvatarPresets() {
      this.dom.avatarPresetsContainer.innerHTML = '';
      PAWTRUST_DATA.avatarPresets.forEach(preset => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = `avatar-preset-btn ${this.formData.selectedAvatar === preset.id ? 'active' : ''}`;
        btn.title = preset.label;
        btn.innerHTML = preset.svg;

        btn.addEventListener('click', () => {
          this.formData.selectedAvatar = preset.id;
          this.formData.customAvatarDataUrl = null;
          this.dom.avatarPresetsContainer.querySelectorAll('.avatar-preset-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          this.renderAvatarPreview();
          this.saveDraftDebounced();
        });

        this.dom.avatarPresetsContainer.appendChild(btn);
      });

      this.renderAvatarPreview();
    },

    renderAvatarPreview() {
      if (this.formData.customAvatarDataUrl) {
        this.dom.avatarPreviewContainer.innerHTML = `<img src="${this.formData.customAvatarDataUrl}" alt="Profile avatar">`;
        return;
      }
      const preset = PAWTRUST_DATA.avatarPresets.find(p => p.id === this.formData.selectedAvatar) || PAWTRUST_DATA.avatarPresets[0];
      this.dom.avatarPreviewContainer.innerHTML = preset.svg;
    },

    handleCustomAvatarUpload(e) {
      const file = e.target.files && e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (loadEvent) => {
        this.formData.customAvatarDataUrl = loadEvent.target.result;
        this.dom.avatarPresetsContainer.querySelectorAll('.avatar-preset-btn').forEach(b => b.classList.remove('active'));
        this.renderAvatarPreview();
        this.saveDraftDebounced();
      };
      reader.readAsDataURL(file);
    },

    handleIdDocumentUpload(e) {
      const file = e.target.files && e.target.files[0];
      if (!file) return;

      this.formData.idUploaded = true;
      this.formData.idFileName = file.name;
      this.dom.idDropZone.classList.add('has-file');

      this.dom.idUploadStatus.innerHTML = `
        <div class="uploaded-file-pill">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Uploaded: ${file.name}</span>
          <button type="button" id="btnRemoveIdFile" style="background:none; border:none; color:var(--rose-600); cursor:pointer; margin-left:0.35rem;">✕</button>
        </div>
      `;

      document.getElementById('btnRemoveIdFile').addEventListener('click', (ev) => {
        ev.stopPropagation();
        this.formData.idUploaded = false;
        this.formData.idFileName = '';
        this.dom.idDropZone.classList.remove('has-file');
        this.dom.idUploadStatus.innerHTML = `
          <label class="btn-demo-trigger" style="cursor:pointer; display:inline-flex;">
            <span>Upload ID Document (Driver's License or Passport)</span>
            <input type="file" id="idFileInput" accept="image/*,.pdf" style="display:none;">
          </label>
        `;
        document.getElementById('idFileInput').addEventListener('change', (ev2) => this.handleIdDocumentUpload(ev2));
        this.saveDraftDebounced();
      });

      this.saveDraftDebounced();
    },

    // ------------------------------------------------------------------------
    // Pet Family Management
    // ------------------------------------------------------------------------
    initBreedSuggestions(species) {
      const breeds = PAWTRUST_DATA.popularBreeds[species] || [];
      this.dom.breedDatalist.innerHTML = '';
      breeds.forEach(breed => {
        const opt = document.createElement('option');
        opt.value = breed;
        this.dom.breedDatalist.appendChild(opt);
      });
    },

    renderPetsList() {
      const pets = this.formData.pets || [];
      this.dom.petsListContainer.innerHTML = '';

      if (pets.length === 0) {
        this.dom.petsListContainer.innerHTML = `
          <div class="empty-pets-box" style="grid-column: 1 / -1;">
            <div class="empty-pets-icon">🐾</div>
            <div style="font-weight:700; color:var(--slate-800); margin-bottom:0.25rem;">No pets added yet</div>
            <div style="font-size:0.82rem; margin-bottom:1rem;">Add your dog, cat, or other animal to find matching caregivers.</div>
            <button type="button" class="btn-demo-trigger" id="btnEmptyAddPet">+ Add Pet Profile</button>
          </div>
        `;
        const btnEmpty = document.getElementById('btnEmptyAddPet');
        if (btnEmpty) btnEmpty.addEventListener('click', () => this.openPetModal());
        return;
      }

      pets.forEach(pet => {
        const card = document.createElement('div');
        card.className = 'pet-card-item';

        const speciesIcons = {
          dog: '🐕', cat: '🐈', bird: '🦜', small_mammal: '🐇', reptile: '🐢', other: '🐾'
        };
        const icon = speciesIcons[pet.species] || '🐾';

        const tempPills = (pet.temperament || [])
          .map(t => `<span class="pet-pill">${t}</span>`)
          .join('');

        card.innerHTML = `
          <div class="pet-card-actions">
            <button type="button" class="btn-remove-pet" title="Remove pet" data-pet-id="${pet.id}">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"/>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
              </svg>
            </button>
          </div>
          <div class="pet-card-top">
            <div class="pet-species-badge">${icon}</div>
            <div>
              <div class="pet-info-name">${this.escapeHtml(pet.name)}</div>
              <div class="pet-info-breed">${this.escapeHtml(pet.breed || pet.species)} • ${this.escapeHtml(pet.age || 'Age unlisted')}</div>
            </div>
          </div>
          <div class="pet-meta-row">
            <span class="pet-pill">${pet.size ? pet.size.toUpperCase() : 'MEDIUM'}</span>
            ${pet.spayedNeutered ? '<span class="pet-pill">✓ Spayed/Neutered</span>' : ''}
            ${tempPills}
          </div>
          ${pet.medicalNotes ? `<div class="pet-notes-snippet"><strong>Notes:</strong> ${this.escapeHtml(pet.medicalNotes)}</div>` : ''}
        `;

        card.querySelector('.btn-remove-pet').addEventListener('click', () => {
          this.removePet(pet.id);
        });

        this.dom.petsListContainer.appendChild(card);
      });
    },

    openPetModal(petToEdit = null) {
      this.dom.petForm.reset();
      this.clearAllFieldErrors();

      if (petToEdit) {
        this.dom.petModalHeading.textContent = 'Edit Pet Details';
        this.dom.petEditId.value = petToEdit.id;
        this.dom.petModalName.value = petToEdit.name;
        this.dom.petModalSpecies.value = petToEdit.species;
        this.initBreedSuggestions(petToEdit.species);
        this.dom.petModalBreed.value = petToEdit.breed || '';
        this.dom.petModalAge.value = petToEdit.age || '';
        this.dom.petModalSize.value = petToEdit.size || 'medium';
        this.dom.petModalSpayed.checked = petToEdit.spayedNeutered !== false;
        this.dom.petModalMedical.value = petToEdit.medicalNotes || '';
        this.dom.petModalVetClinic.value = petToEdit.vetClinic || '';
        this.dom.petModalVetPhone.value = petToEdit.vetPhone || '';

        // Reset chips
        this.dom.petTemperamentChips.querySelectorAll('.choice-chip').forEach(c => {
          const val = c.getAttribute('data-temp');
          c.classList.toggle('active', (petToEdit.temperament || []).includes(val));
        });
      } else {
        this.dom.petModalHeading.textContent = 'Add Pet to Your Family';
        this.dom.petEditId.value = '';
        this.dom.petModalSpecies.value = 'dog';
        this.initBreedSuggestions('dog');
        this.dom.petModalSpayed.checked = true;
      }

      this.openModal('petModal');
    },

    handleSavePet() {
      const name = this.dom.petModalName.value.trim();
      const errorSpan = document.getElementById('error_petModalName');

      if (!name || name.length < 1) {
        errorSpan.textContent = 'Please enter your pet’s name.';
        errorSpan.classList.add('show');
        this.dom.petModalName.classList.add('is-invalid');
        return;
      }

      const activeTemps = [];
      this.dom.petTemperamentChips.querySelectorAll('.choice-chip.active').forEach(c => {
        activeTemps.push(c.getAttribute('data-temp'));
      });

      const editId = this.dom.petEditId.value;
      const petData = {
        id: editId || 'pet_' + Date.now(),
        name,
        species: this.dom.petModalSpecies.value,
        breed: this.dom.petModalBreed.value.trim(),
        age: this.dom.petModalAge.value.trim(),
        size: this.dom.petModalSize.value,
        spayedNeutered: this.dom.petModalSpayed.checked,
        temperament: activeTemps,
        medicalNotes: this.dom.petModalMedical.value.trim(),
        vetClinic: this.dom.petModalVetClinic.value.trim(),
        vetPhone: this.dom.petModalVetPhone.value.trim()
      };

      if (editId) {
        const idx = this.formData.pets.findIndex(p => p.id === editId);
        if (idx >= 0) this.formData.pets[idx] = petData;
      } else {
        this.formData.pets.push(petData);
      }

      this.closeModal('petModal');
      this.renderPetsList();
      this.saveDraftDebounced();
    },

    removePet(petId) {
      this.formData.pets = this.formData.pets.filter(p => p.id !== petId);
      this.renderPetsList();
      this.saveDraftDebounced();
    },

    quickAddSamplePet() {
      const samples = [
        {
          id: 'sample_pet_' + Date.now(),
          name: 'Cooper',
          species: 'dog',
          breed: 'Golden Retriever',
          age: '3 years',
          size: 'large',
          spayedNeutered: true,
          temperament: ['Friendly with Dogs', 'Good with Kids', 'High Energy'],
          medicalNotes: 'Fully vaccinated. Loves fetching tennis balls and water playtime.',
          vetClinic: 'Rose City Animal Hospital',
          vetPhone: '(555) 321-7788'
        },
        {
          id: 'sample_pet_' + (Date.now() + 1),
          name: 'Mochi',
          species: 'cat',
          breed: 'Domestic Shorthair',
          age: '2 years',
          size: 'small',
          spayedNeutered: true,
          temperament: ['Friendly with Cats', 'Cuddle Bug'],
          medicalNotes: 'Indoor-only cat. Very affectionate.',
          vetClinic: 'Sunset Cat Clinic',
          vetPhone: '(555) 654-9988'
        }
      ];

      const toAdd = samples[Math.floor(Math.random() * samples.length)];
      toAdd.id = 'pet_' + Date.now();
      this.formData.pets.push(toAdd);
      this.renderPetsList();
      this.saveDraftDebounced();
    },

    // ------------------------------------------------------------------------
    // Sync Helpers for Dynamic DOM elements
    // ------------------------------------------------------------------------
    syncCaregiverRatesFromDom() {
      ['walking', 'sitting', 'boarding', 'dropin'].forEach(service => {
        const chk = document.getElementById(`offer_${service}`);
        const rateInput = document.getElementById(`rate_${service}`);
        if (chk && rateInput) {
          const key = service === 'dropin' ? 'drop_in' : service;
          this.formData.servicesOffered[key] = {
            enabled: chk.checked,
            rate: rateInput.value
          };
        }
      });
    },

    syncCaregiverSkillsFromDom() {
      const skills = [];
      this.dom.caregiverSkillsChips.querySelectorAll('.choice-chip.active').forEach(chip => {
        skills.push(chip.getAttribute('data-skill'));
      });
      this.formData.caregiverExperience.skills = skills;
    },

    syncServicesNeededFromDom() {
      const needed = [];
      document.querySelectorAll('input[name="servicesNeeded"]:checked').forEach(chk => {
        needed.push(chk.value);
      });
      this.formData.servicesNeeded = needed;
    },

    // ------------------------------------------------------------------------
    // Step 4 Review Summary Renderer
    // ------------------------------------------------------------------------
    renderReviewSummary() {
      this.syncFormDataFromDom();
      this.syncCaregiverRatesFromDom();
      this.syncCaregiverSkillsFromDom();
      this.syncServicesNeededFromDom();

      this.dom.revName.textContent = `${this.formData.firstName || ''} ${this.formData.lastName || ''}`.trim() || 'Not specified';
      
      const roleLabels = {
        owner: 'Pet Owner',
        caregiver: 'Pet Caregiver',
        both: 'Owner & Sitter'
      };
      this.dom.revRole.textContent = roleLabels[this.formData.accountType] || 'Pet Owner';
      this.dom.revEmail.textContent = this.formData.email || 'Not specified';
      this.dom.revPhone.textContent = this.formData.phone || 'Not specified';
      this.dom.revLocation.textContent = `${this.formData.city || ''}, ${this.formData.state || ''} ${this.formData.zipCode || ''}`.trim() || 'Not specified';
      this.dom.revEmergency.textContent = `${this.formData.emergencyContactName || ''} (${this.formData.emergencyContactPhone || ''})`.trim() || 'Not specified';

      // Pets or Caregiver summary details
      let summaryHtml = '';
      if (this.formData.accountType === 'owner' || this.formData.accountType === 'both') {
        const petNames = (this.formData.pets || []).map(p => `<strong>${this.escapeHtml(p.name)}</strong> (${p.breed || p.species})`).join(', ');
        const servicesList = (this.formData.servicesNeeded || []).join(', ');
        summaryHtml += `<p>🐾 <strong>Pets Registered:</strong> ${petNames || 'None added yet'}</p>`;
        summaryHtml += `<p>📋 <strong>Services Needed:</strong> ${servicesList || 'None selected'}</p>`;
      }

      if (this.formData.accountType === 'caregiver' || this.formData.accountType === 'both') {
        const offered = this.formData.servicesOffered || {};
        const activeOffered = Object.keys(offered)
          .filter(k => offered[k] && offered[k].enabled)
          .map(k => `${k.replace('_', ' ')} ($${offered[k].rate})`)
          .join(', ');

        summaryHtml += `<p>🤝 <strong>Services &amp; Rates:</strong> ${activeOffered || 'None configured'}</p>`;
        summaryHtml += `<p>🎓 <strong>Experience:</strong> ${this.formData.caregiverExperience.yearsExperience || 0} years • ${this.formData.caregiverExperience.skills.join(', ')}</p>`;
      }

      this.dom.revPetsSummary.innerHTML = summaryHtml;
    },

    // ------------------------------------------------------------------------
    // Form Submission & Simulated API Handling
    // ------------------------------------------------------------------------
    async handleFormSubmit(e) {
      e.preventDefault();

      this.syncFormDataFromDom();
      this.syncCaregiverRatesFromDom();
      this.syncCaregiverSkillsFromDom();
      this.syncServicesNeededFromDom();

      // Full Form Validation
      const fullValidation = PawValidation.validateAll(this.formData);
      if (!fullValidation.isValid) {
        // Find which step failed first and navigate there
        const steps = fullValidation.stepValidity;
        if (!steps.step1) this.goToStep(1);
        else if (!steps.step2) this.goToStep(2);
        else if (!steps.step3) this.goToStep(3);
        else if (!steps.step4) this.goToStep(4);

        this.displayFieldErrors(fullValidation.errors);
        this.showAlertBanner('Please correct all required fields to complete registration.');
        return;
      }

      // Show submission overlay
      this.dom.submitOverlay.classList.add('show');
      this.dom.submitStatusTitle.textContent = 'Securing Account...';
      this.dom.submitStatusDesc.textContent = 'Connecting to PawTrust secure service...';
      this.dom.submitProgressBar.style.width = '20%';

      try {
        const response = await PawMockApi.registerUser(this.formData, (msg, percent) => {
          this.dom.submitStatusDesc.textContent = msg;
          this.dom.submitProgressBar.style.width = `${percent}%`;
        });

        // Registration Successful!
        setTimeout(() => {
          this.dom.submitOverlay.classList.remove('show');
          this.showRegistrationSuccess(response);
        }, 300);

      } catch (err) {
        // Handled simulated errors (409 Conflict / 500 Server Error)
        setTimeout(() => {
          this.dom.submitOverlay.classList.remove('show');
          this.showAlertBanner(err.message || 'Registration failed. Please check your details and retry.');
          if (err.code === 'EMAIL_ALREADY_EXISTS') {
            this.goToStep(1);
            const errEmail = document.getElementById('error_email');
            if (errEmail) {
              errEmail.textContent = 'This email is already registered on PawTrust.';
              errEmail.classList.add('show');
            }
          }
        }, 400);
      }
    },

    showRegistrationSuccess(response) {
      // Hide form & stepper
      this.dom.form.style.display = 'none';
      this.dom.form.closest('.registration-card').querySelector('.stepper-container').style.display = 'none';

      // Show celebration view
      this.dom.successView.classList.add('active');

      const user = response.user;
      this.dom.successWelcomeMsg.textContent = `Welcome to PawTrust, ${user.firstName}! Your ${user.accountType === 'caregiver' ? 'caregiver' : 'member'} profile has been created.`;
      this.dom.successMemberId.textContent = user.memberNumber;

      const roleBadges = {
        owner: '🐕 Pet Owner',
        caregiver: '🤝 Pet Caregiver',
        both: '⭐ Owner & Caregiver'
      };
      this.dom.successAccountTypeBadge.textContent = roleBadges[user.accountType] || 'Member';

      // Format payload for developer inspection
      this.dom.payloadJsonPre.textContent = JSON.stringify(response, null, 2);

      // Trigger Confetti Party!
      PawConfetti.burst(150);
      setTimeout(() => PawConfetti.burst(80), 800);
    },

    // ------------------------------------------------------------------------
    // Draft Persistence & Sample Quick Fills
    // ------------------------------------------------------------------------
    saveDraftDebounced() {
      clearTimeout(this._saveTimeout);
      this._saveTimeout = setTimeout(() => {
        this.syncFormDataFromDom();
        this.syncCaregiverRatesFromDom();
        this.syncCaregiverSkillsFromDom();
        this.syncServicesNeededFromDom();

        PawMockApi.saveDraft(this.formData);

        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        this.dom.draftStatusText.textContent = `Draft saved at ${timeStr}`;
      }, 350);
    },

    loadDraftOrDefaults() {
      const draftObj = PawMockApi.getDraft();
      if (draftObj && draftObj.data) {
        this.formData = Object.assign({}, this.formData, draftObj.data);
        this.populateDomFromFormData();
        if (draftObj.timestamp) {
          const dt = new Date(draftObj.timestamp);
          this.dom.draftStatusText.textContent = `Draft restored (${dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`;
        }
      }
    },

    populateDomFromFormData() {
      this.dom.firstNameInput.value = this.formData.firstName || '';
      this.dom.lastNameInput.value = this.formData.lastName || '';
      this.dom.emailInput.value = this.formData.email || '';
      this.dom.phoneInput.value = this.formData.phone || '';
      this.dom.passwordInput.value = this.formData.password || '';
      this.dom.confirmPasswordInput.value = this.formData.confirmPassword || '';

      this.dom.streetAddressInput.value = this.formData.streetAddress || '';
      this.dom.cityInput.value = this.formData.city || '';
      this.dom.stateSelect.value = this.formData.state || '';
      this.dom.zipCodeInput.value = this.formData.zipCode || '';
      this.dom.neighborhoodRadiusSelect.value = this.formData.neighborhoodRadius || '10';
      this.dom.bioTextarea.value = this.formData.bio || '';
      this.dom.emergencyContactNameInput.value = this.formData.emergencyContactName || '';
      this.dom.emergencyContactPhoneInput.value = this.formData.emergencyContactPhone || '';

      // Update bio count
      const bioLen = (this.formData.bio || '').length;
      this.dom.bioCounter.textContent = `${bioLen} / 20 min characters`;

      // Update password check
      this.handlePasswordInput();

      // Update caregiver services & rates
      const offered = this.formData.servicesOffered || {};
      ['walking', 'sitting', 'boarding', 'dropin'].forEach(service => {
        const key = service === 'dropin' ? 'drop_in' : service;
        const conf = offered[key];
        const chk = document.getElementById(`offer_${service}`);
        const rateInput = document.getElementById(`rate_${service}`);
        const row = document.getElementById(`rateRow_${service}`);

        if (conf && chk && rateInput && row) {
          chk.checked = !!conf.enabled;
          rateInput.value = conf.rate || '25';
          row.classList.toggle('active', chk.checked);
          rateInput.disabled = !chk.checked;
        }
      });

      // Update caregiver skills chips
      const skills = (this.formData.caregiverExperience && this.formData.caregiverExperience.skills) || [];
      this.dom.caregiverSkillsChips.querySelectorAll('.choice-chip').forEach(chip => {
        const skillName = chip.getAttribute('data-skill');
        chip.classList.toggle('active', skills.includes(skillName));
      });

      // Update services needed checkboxes
      const needed = this.formData.servicesNeeded || [];
      document.querySelectorAll('input[name="servicesNeeded"]').forEach(chk => {
        const isChecked = needed.includes(chk.value);
        chk.checked = isChecked;
        const parentCard = chk.closest('.service-check-card');
        if (parentCard) parentCard.classList.toggle('checked', isChecked);
      });

      // Update ID Upload status
      if (this.formData.idUploaded && this.formData.idFileName) {
        this.dom.idDropZone.classList.add('has-file');
        this.dom.idUploadStatus.innerHTML = `
          <div class="uploaded-file-pill">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            <span>Uploaded: ${this.formData.idFileName}</span>
          </div>
        `;
      }

      this.dom.agreeTermsCheckbox.checked = !!this.formData.agreeTerms;
      this.dom.agreeWelfareCheckbox.checked = !!this.formData.agreeWelfare;
      this.dom.agreeBackgroundCheckCheckbox.checked = !!this.formData.agreeBackgroundCheck;
      this.dom.agreeNotificationsCheckbox.checked = this.formData.smsNotifications !== false;

      this.renderAvatarPreview();
    },

    applySampleProfile(profileKey) {
      const sample = PAWTRUST_DATA.sampleProfiles[profileKey];
      if (!sample) return;

      this.formData = JSON.parse(JSON.stringify(sample));
      this.populateDomFromFormData();
      this.updateRoleView();
      this.renderPetsList();
      this.saveDraftDebounced();

      // Show feedback badge
      this.dom.draftStatusText.textContent = `Loaded sample: ${sample.firstName} (${profileKey.toUpperCase()})`;
    },

    // ------------------------------------------------------------------------
    // Modal Helpers
    // ------------------------------------------------------------------------
    initLegalModals() {
      document.getElementById('termsModalContent').innerHTML = PAWTRUST_DATA.legalTexts.termsOfService;
      document.getElementById('welfareModalContent').innerHTML = PAWTRUST_DATA.legalTexts.codeOfConduct;

      // Close modal on escape key
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          document.querySelectorAll('.modal-overlay.show').forEach(m => m.classList.remove('show'));
        }
      });
    },

    openModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) modal.classList.add('show');
    },

    closeModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) modal.classList.remove('show');
    },

    escapeHtml(text) {
      if (!text) return '';
      return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }
  };

  // Launch application
  App.init();
  window.PawApp = App;
});

