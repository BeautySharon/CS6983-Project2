import { BASE_URL } from '../config';

/**
 * Universal API fetch helper for PawTrust.
 * - Injects JWT Bearer token from localStorage
 * - Prefixes URL with BASE_URL and /pawtrust if needed
 * - Clears credentials and redirects on 401
 */
export async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('pawtrust.token');

  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Ensure path starts with /pawtrust prefix if not present and relative
  let endpoint = path;
  if (!endpoint.startsWith('http://') && !endpoint.startsWith('https://')) {
    if (!endpoint.startsWith('/pawtrust')) {
      endpoint = `/pawtrust${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
    }
    endpoint = `${BASE_URL}${endpoint}`;
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  if (response.status === 401) {
    localStorage.removeItem('pawtrust.token');
    localStorage.removeItem('pawtrust.user');
    if (typeof window !== 'undefined' && window.location.pathname !== '/') {
      window.location.href = '/';
    }
  }

  let data;
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    data = await response.json();
  } else {
    data = await response.text();
  }

  if (!response.ok) {
    const errorMsg = (data && data.error) || (typeof data === 'string' && data) || response.statusText || 'Request failed';
    const error = new Error(errorMsg);
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
}
