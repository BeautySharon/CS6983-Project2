import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { apiFetch } from '../client';

describe('apiFetch Client Helper', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.restoreAllMocks();
  });

  afterEach(() => {
    localStorage.clear();
  });

  it('injects Authorization header when token exists in localStorage', async () => {
    localStorage.setItem('pawtrust.token', 'test-jwt-token');

    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      headers: { get: () => 'application/json' },
      json: async () => ({ success: true }),
    });
    global.fetch = fetchMock;

    const data = await apiFetch('/test');

    expect(fetchMock).toHaveBeenCalledWith(
      'http://localhost:8000/pawtrust/test',
      expect.objectContaining({
        headers: expect.objectContaining({
          Authorization: 'Bearer test-jwt-token',
          'Content-Type': 'application/json',
        }),
      })
    );
    expect(data).toEqual({ success: true });
  });

  it('clears token and user on 401 response', async () => {
    localStorage.setItem('pawtrust.token', 'expired-token');
    localStorage.setItem('pawtrust.user', JSON.stringify({ id: 'u1' }));

    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 401,
      statusText: 'Unauthorized',
      headers: { get: () => 'application/json' },
      json: async () => ({ error: 'Unauthorized' }),
    });
    global.fetch = fetchMock;

    await expect(apiFetch('/protected')).rejects.toThrow('Unauthorized');
    expect(localStorage.getItem('pawtrust.token')).toBeNull();
    expect(localStorage.getItem('pawtrust.user')).toBeNull();
  });

  it('throws an error with message from error field on non-200 responses', async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 409,
      statusText: 'Conflict',
      headers: { get: () => 'application/json' },
      json: async () => ({ error: 'Email already registered' }),
    });
    global.fetch = fetchMock;

    await expect(apiFetch('/register')).rejects.toThrow('Email already registered');
  });
});
