import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import RegisterPage from '../pages/RegisterPage';
import * as client from '../api/client';

const mockedNavigate = vi.fn();
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => mockedNavigate,
  };
});

describe('RegisterPage Component (US-1)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  const renderComponent = () =>
    render(
      <MemoryRouter>
        <RegisterPage />
      </MemoryRouter>
    );

  it('renders all form fields, labels, roles, and buttons per mockup', () => {
    renderComponent();

    // Brand and Headings
    expect(screen.getByText('PawTrust')).toBeInTheDocument();
    expect(screen.getByText('Connect pet owners with trusted sitters.')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /create an account/i })).toBeInTheDocument();
    expect(screen.getByText(/join pawtrust as a pet owner or pet sitter/i)).toBeInTheDocument();

    // Inputs with labels
    expect(screen.getByLabelText(/^name$/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/^email$/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/^password$/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/location/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/bio \(optional\)/i)).toBeInTheDocument();

    // User Type radios
    const ownerRadio = screen.getByRole('radio', { name: /pet owner/i });
    const sitterRadio = screen.getByRole('radio', { name: /pet sitter/i });
    expect(ownerRadio).toBeInTheDocument();
    expect(sitterRadio).toBeInTheDocument();
    expect(ownerRadio).toBeChecked();
    expect(sitterRadio).not.toBeChecked();

    // Submit button & login link
    expect(screen.getByRole('button', { name: /create account/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /login here/i })).toBeInTheDocument();
  });

  it('toggles password visibility when the show/hide button is clicked', async () => {
    const user = userEvent.setup();
    renderComponent();

    const passwordInput = screen.getByLabelText(/^password$/i);
    const toggleBtn = screen.getByRole('button', { name: /show password/i });

    expect(passwordInput).toHaveAttribute('type', 'password');

    await user.click(toggleBtn);
    expect(passwordInput).toHaveAttribute('type', 'text');
    expect(screen.getByRole('button', { name: /hide password/i })).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: /hide password/i }));
    expect(passwordInput).toHaveAttribute('type', 'password');
  });

  it('shows validation error when password is less than 8 characters', async () => {
    const user = userEvent.setup();
    renderComponent();

    await user.type(screen.getByLabelText(/^name$/i), 'Jane Doe');
    await user.type(screen.getByLabelText(/^email$/i), 'jane@example.com');
    await user.type(screen.getByLabelText(/^password$/i), 'short');
    await user.type(screen.getByLabelText(/location/i), 'San Jose, CA');

    await user.click(screen.getByRole('button', { name: /create account/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent(/must be at least 8 characters/i);
  });

  it('allows selecting Pet Sitter role', async () => {
    const user = userEvent.setup();
    renderComponent();

    const sitterRadio = screen.getByRole('radio', { name: /pet sitter/i });
    const ownerRadio = screen.getByRole('radio', { name: /pet owner/i });

    await user.click(sitterRadio);
    expect(sitterRadio).toBeChecked();
    expect(ownerRadio).not.toBeChecked();
  });

  it('submits registration successfully when backend responds', async () => {
    const user = userEvent.setup();
    const apiFetchSpy = vi.spyOn(client, 'apiFetch').mockResolvedValueOnce({
      user: { id: 'u1', name: 'Jane Doe', email: 'jane@example.com', userType: 'owner' },
    });

    renderComponent();

    await user.type(screen.getByLabelText(/^name$/i), 'Jane Doe');
    await user.type(screen.getByLabelText(/^email$/i), 'jane@example.com');
    await user.type(screen.getByLabelText(/^password$/i), 'password123');
    await user.type(screen.getByLabelText(/location/i), 'San Jose, CA');
    await user.type(screen.getByLabelText(/bio \(optional\)/i), 'I have two golden retrievers.');

    await user.click(screen.getByRole('button', { name: /create account/i }));

    await waitFor(() => {
      expect(apiFetchSpy).toHaveBeenCalledWith('/register', {
        method: 'POST',
        body: JSON.stringify({
          name: 'Jane Doe',
          email: 'jane@example.com',
          password: 'password123',
          userType: 'owner',
          location: 'San Jose, CA',
          bio: 'I have two golden retrievers.',
        }),
      });
    });

    expect(await screen.findByRole('status')).toHaveTextContent(/registration successful/i);
  });

  it('displays error message when duplicate email error is returned', async () => {
    const user = userEvent.setup();
    const duplicateError = new Error('Email already registered');
    duplicateError.status = 409;
    duplicateError.data = { error: 'Email already registered' };

    vi.spyOn(client, 'apiFetch').mockRejectedValueOnce(duplicateError);

    renderComponent();

    await user.type(screen.getByLabelText(/^name$/i), 'Existing User');
    await user.type(screen.getByLabelText(/^email$/i), 'duplicate@example.com');
    await user.type(screen.getByLabelText(/^password$/i), 'password123');
    await user.type(screen.getByLabelText(/location/i), 'San Jose, CA');

    await user.click(screen.getByRole('button', { name: /create account/i }));

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent('Email already registered');
  });

  it('handles offline / demo mode gracefully when backend is not connected', async () => {
    const user = userEvent.setup();
    // Simulate Failed to fetch network error
    vi.spyOn(client, 'apiFetch').mockRejectedValueOnce(new TypeError('Failed to fetch'));

    renderComponent();

    await user.type(screen.getByLabelText(/^name$/i), 'Offline Tester');
    await user.type(screen.getByLabelText(/^email$/i), 'offline@example.com');
    await user.type(screen.getByLabelText(/^password$/i), 'password123');
    await user.type(screen.getByLabelText(/location/i), 'San Jose, CA');

    await user.click(screen.getByRole('button', { name: /create account/i }));

    // Should succeed in demo fallback mode
    expect(await screen.findByRole('status')).toHaveTextContent(/registration successful/i);
  });
});
